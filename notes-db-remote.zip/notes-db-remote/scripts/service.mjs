// Install or remove notes-db-remote as a Windows service.
//   node scripts/service.mjs install
//   node scripts/service.mjs uninstall
// Run from an elevated (Administrator) PowerShell. Requires: npm install node-windows
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
let Service;
try {
  ({ Service } = require("node-windows"));
} catch {
  console.error("node-windows isn't installed. Run: npm install node-windows");
  process.exit(1);
}

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const svc = new Service({
  name: "Notes DB MCP",
  description: "Remote MCP server for the Team Notes app (Claude custom connector).",
  script: path.join(root, "src", "server.mjs"),
  workingDirectory: root,
  env: [{ name: "NOTES_ENV_FILE", value: path.join(root, ".env") }],
});

const action = process.argv[2];
svc.on("install", () => {
  console.log("Installed. Starting...");
  svc.start();
});
svc.on("start", () => console.log("Started. Set the service's Log On account in services.msc (see README)."));
svc.on("uninstall", () => console.log("Uninstalled."));
svc.on("alreadyinstalled", () => console.log("Already installed."));
svc.on("error", (e) => console.error("Service error:", e));

if (action === "install") svc.install();
else if (action === "uninstall") svc.uninstall();
else console.log("Usage: node scripts/service.mjs install|uninstall");
