// All configuration comes from environment variables (see .env.example).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Minimal .env loader so a Windows service can read settings from a file
// next to the app. Real environment variables win over the file.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const envFile = process.env.NOTES_ENV_FILE || path.join(root, ".env");
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith("#")) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}

function req(name) {
  const v = process.env[name];
  if (!v) {
    console.error(`notes-db-remote: missing required setting ${name}`);
    process.exit(1);
  }
  return v;
}

const tenant = req("ENTRA_TENANT_ID");
const clientId = req("ENTRA_CLIENT_ID");
const authority = (process.env.ENTRA_AUTHORITY || `https://login.microsoftonline.com/${tenant}`).replace(/\/$/, "");
const baseUrl = req("PUBLIC_BASE_URL").replace(/\/$/, "");

export const config = {
  port: Number(process.env.PORT || 8787),
  host: process.env.HOST || "127.0.0.1", // behind a reverse proxy, listen locally only
  baseUrl, // public https URL the reverse proxy serves, e.g. https://notes-mcp.example.com
  mcpPath: "/mcp",

  entra: {
    tenant,
    clientId,
    clientSecret: req("ENTRA_CLIENT_SECRET"),
    authority,
    authorizeUrl: `${authority}/oauth2/v2.0/authorize`,
    tokenUrl: `${authority}/oauth2/v2.0/token`,
    jwksUrl: process.env.ENTRA_JWKS_URL || `${authority}/discovery/v2.0/keys`,
    // v2 and v1 token issuers (which one depends on the app's accessTokenAcceptedVersion)
    issuers: (process.env.ENTRA_ISSUERS || `https://login.microsoftonline.com/${tenant}/v2.0,https://sts.windows.net/${tenant}/`)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
    apiScope: process.env.ENTRA_API_SCOPE || `api://${clientId}/notes.readwrite`,
    requiredRole: process.env.ENTRA_REQUIRED_ROLE || "", // optional app role, e.g. Notes.User
  },

  // Only these OAuth redirect URIs are accepted (Claude's callbacks).
  allowedRedirectUris: (process.env.ALLOWED_REDIRECT_URIS || "https://claude.ai/api/mcp/auth_callback,https://claude.com/api/mcp/auth_callback")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),

  sql: {
    server: process.env.MSSQL_SERVER || "BELFAST",
    port: Number(process.env.MSSQL_PORT) || undefined,
    database: process.env.MSSQL_DATABASE || "Notes",
    table: process.env.MSSQL_TABLE || "dbo.Notes",
    // "integrated": the Windows account the service runs as (needs msnodesqlv8 + ODBC driver)
    // "ntlm": a Windows account given by DOMAIN\\user + password
    // "sql": a SQL Server login
    auth: (process.env.MSSQL_AUTH || "integrated").toLowerCase(),
    user: process.env.MSSQL_USER || "",
    password: process.env.MSSQL_PASSWORD || "",
    odbcDriver: process.env.MSSQL_ODBC_DRIVER || "ODBC Driver 18 for SQL Server",
    trustCert: (process.env.MSSQL_TRUST_CERT || "true").toLowerCase() === "true",
  },
};
