// SQL Server access for the Notes table. Only these four parameterized
// statements are ever run.
import { config } from "./config.mjs";

const c = config.sql;
if (!/^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$/.test(c.table)) {
  console.error(`notes-db-remote: invalid MSSQL_TABLE "${c.table}"`);
  process.exit(1);
}
const TABLE = c.table.split(".").map((p) => `[${p}]`).join(".");

let sql;
let poolPromise = null;

async function loadDriver() {
  if (c.auth === "integrated") {
    try {
      return (await import("mssql/msnodesqlv8.js")).default;
    } catch {
      throw new Error("MSSQL_AUTH=integrated needs the msnodesqlv8 package: run `npm install msnodesqlv8`.");
    }
  }
  return (await import("mssql")).default;
}

function poolConfig() {
  const [host, instanceName] = c.server.split("\\");
  if (c.auth === "integrated") {
    return {
      connectionString:
        `Driver={${c.odbcDriver}};Server=${c.server}${c.port && !instanceName ? "," + c.port : ""};Database=${c.database};` +
        `Trusted_Connection=yes;TrustServerCertificate=${c.trustCert ? "yes" : "no"};`,
    };
  }
  const base = {
    server: host,
    database: c.database,
    options: { instanceName, encrypt: true, trustServerCertificate: c.trustCert },
    pool: { max: 10, min: 0, idleTimeoutMillis: 30000 },
    connectionTimeout: 15000,
    requestTimeout: 30000,
  };
  if (c.port && !instanceName) base.port = c.port;
  if (!c.user || !c.password) throw new Error(`MSSQL_AUTH=${c.auth} needs MSSQL_USER and MSSQL_PASSWORD.`);
  if (c.auth === "ntlm") {
    let domain = "", userName = c.user;
    if (c.user.includes("\\")) [domain, userName] = c.user.split("\\");
    else if (c.user.includes("@")) [userName, domain] = c.user.split("@");
    if (!domain) throw new Error('MSSQL_AUTH=ntlm needs MSSQL_USER as "DOMAIN\\user".');
    return { ...base, authentication: { type: "ntlm", options: { domain, userName, password: c.password } } };
  }
  return { ...base, user: c.user, password: c.password };
}

export async function getPool() {
  if (poolPromise) return poolPromise;
  poolPromise = (async () => {
    sql = await loadDriver();
    return new sql.ConnectionPool(poolConfig()).connect();
  })().catch((e) => {
    poolPromise = null;
    throw e;
  });
  return poolPromise;
}

function toRow(r) {
  return {
    id: String(r.id),
    note: r.note == null ? "" : String(r.note),
    created_by: r.created_by == null ? "" : String(r.created_by),
    updated_date: r.updated_date instanceof Date ? r.updated_date.toISOString() : r.updated_date ?? null,
  };
}

const COLS = "INSERTED.[id], INSERTED.[note], INSERTED.[created_by], INSERTED.[updated_date]";

export async function listNotes() {
  const pool = await getPool();
  const r = await pool.request().query(`SELECT [id], [note], [created_by], [updated_date] FROM ${TABLE} ORDER BY [updated_date] DESC`);
  return r.recordset.map(toRow);
}

export async function addNote(note, createdBy) {
  const pool = await getPool();
  const r = await pool
    .request()
    .input("note", sql.NVarChar(sql.MAX), note)
    .input("created_by", sql.NVarChar(200), createdBy)
    .query(`INSERT INTO ${TABLE} ([note], [created_by], [updated_date]) OUTPUT ${COLS} VALUES (@note, @created_by, SYSDATETIME())`);
  return toRow(r.recordset[0]);
}

export async function updateNote(id, note) {
  const pool = await getPool();
  const r = await pool
    .request()
    .input("id", sql.NVarChar(100), id)
    .input("note", sql.NVarChar(sql.MAX), note)
    .query(`UPDATE ${TABLE} SET [note] = @note, [updated_date] = SYSDATETIME() OUTPUT ${COLS} WHERE [id] = @id`);
  return r.recordset[0] ? toRow(r.recordset[0]) : null;
}

export async function deleteNote(id) {
  const pool = await getPool();
  const r = await pool.request().input("id", sql.NVarChar(100), id).query(`DELETE FROM ${TABLE} WHERE [id] = @id`);
  return r.rowsAffected[0] ?? 0;
}

export function describeTarget() {
  return `${c.server}/${c.database} ${TABLE} (${c.auth} auth)`;
}
