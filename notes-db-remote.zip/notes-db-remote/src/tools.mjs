// The four MCP tools. `user` is the signed-in Entra user for this request;
// created_by is always taken from the sign-in token, never from the caller.
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { listNotes, addNote, updateNote, deleteNote } from "./db.mjs";

const MAX_NOTE = 4000;

const ok = (payload) => ({ content: [{ type: "text", text: JSON.stringify(payload) }], structuredContent: payload });
const fail = (e) => ({ isError: true, content: [{ type: "text", text: e?.originalError?.message || e?.message || String(e) }] });

export function buildServer(user) {
  const server = new McpServer({ name: "notes-db", version: "2.0.0" });

  server.registerTool(
    "list_notes",
    { title: "List notes", description: "List all notes in the Notes table, newest update first.", inputSchema: {}, annotations: { readOnlyHint: true } },
    async () => {
      try {
        return ok({ notes: await listNotes() });
      } catch (e) {
        return fail(e);
      }
    },
  );

  server.registerTool(
    "add_note",
    {
      title: "Add note",
      description: "Insert a new note. The author is recorded from your sign-in.",
      inputSchema: {
        note: z.string().min(1).max(MAX_NOTE),
        created_by: z.string().max(200).optional().describe("Ignored: the author is taken from your sign-in."),
      },
      annotations: { readOnlyHint: false, destructiveHint: false },
    },
    async ({ note }) => {
      try {
        return ok({ note: await addNote(note, user.displayName) });
      } catch (e) {
        return fail(e);
      }
    },
  );

  server.registerTool(
    "update_note",
    {
      title: "Update note",
      description: "Change the text of an existing note.",
      inputSchema: { id: z.string().min(1).max(100), note: z.string().min(1).max(MAX_NOTE) },
      annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    },
    async ({ id, note }) => {
      try {
        const row = await updateNote(id, note);
        return row ? ok({ note: row }) : fail(new Error(`No note with id ${id}. It may have been deleted.`));
      } catch (e) {
        return fail(e);
      }
    },
  );

  server.registerTool(
    "delete_note",
    {
      title: "Delete note",
      description: "Delete one note by id.",
      inputSchema: { id: z.string().min(1).max(100) },
      annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: true },
    },
    async ({ id }) => {
      try {
        return ok({ deleted: await deleteNote(id), id });
      } catch (e) {
        return fail(e);
      }
    },
  );

  return server;
}
