// OAuth for Claude custom connectors, backed by Microsoft Entra ID.
//
// Claude expects an MCP-style OAuth server: protected-resource metadata,
// authorization-server metadata, Dynamic Client Registration, and the
// `resource` parameter. Entra has no DCR and rejects `resource` on its v2
// endpoints, so this module is a thin facade:
//   - /register returns this app's Entra client id (public client, PKCE)
//   - /authorize redirects to Entra with our API scope, minus `resource`
//   - /token forwards to Entra, adding the client secret server-side
// Entra does all user sign-in; access tokens are Entra JWTs, verified here.
import express from "express";
import { createRemoteJWKSet, jwtVerify } from "jose";
import { config } from "./config.mjs";

const { entra, baseUrl, mcpPath, allowedRedirectUris } = config;
const resourceUrl = `${baseUrl}${mcpPath}`;
const prmUrl = `${baseUrl}/.well-known/oauth-protected-resource${mcpPath}`;
const scopeName = entra.apiScope.split("/").pop(); // e.g. notes.readwrite
const requestScopes = `${entra.apiScope} offline_access openid profile`;

// ---------- metadata ----------

const protectedResource = {
  resource: resourceUrl,
  authorization_servers: [baseUrl],
  scopes_supported: [entra.apiScope],
  bearer_methods_supported: ["header"],
  resource_name: "Notes DB",
};

const authServer = {
  issuer: baseUrl,
  authorization_endpoint: `${baseUrl}/authorize`,
  token_endpoint: `${baseUrl}/token`,
  registration_endpoint: `${baseUrl}/register`,
  response_types_supported: ["code"],
  grant_types_supported: ["authorization_code", "refresh_token"],
  code_challenge_methods_supported: ["S256"],
  token_endpoint_auth_methods_supported: ["none", "client_secret_post", "client_secret_basic"],
  scopes_supported: [entra.apiScope, "offline_access"],
};

// ---------- helpers ----------

function oauthError(res, status, error, description) {
  res.status(status).set("Cache-Control", "no-store").json({ error, error_description: description });
}

function clientFromRequest(req) {
  const h = req.headers.authorization || "";
  if (h.startsWith("Basic ")) {
    const [id] = Buffer.from(h.slice(6), "base64").toString("utf8").split(":");
    return decodeURIComponent(id || "");
  }
  return req.body?.client_id || "";
}

// ---------- router ----------

export function oauthRouter() {
  const r = express.Router();
  r.use(express.urlencoded({ extended: false }));

  r.get(["/.well-known/oauth-protected-resource", `/.well-known/oauth-protected-resource${mcpPath}`], (_req, res) =>
    res.json(protectedResource),
  );
  r.get("/.well-known/oauth-authorization-server", (_req, res) => res.json(authServer));

  // Dynamic Client Registration (RFC 7591). Every client gets the same Entra
  // client id; only Claude's callback URLs are accepted.
  r.post("/register", express.json(), (req, res) => {
    const uris = Array.isArray(req.body?.redirect_uris) ? req.body.redirect_uris : [];
    if (!uris.length || uris.some((u) => !allowedRedirectUris.includes(u))) {
      return oauthError(res, 400, "invalid_redirect_uri", "Only Claude's connector callback URLs are allowed.");
    }
    res.status(201).set("Cache-Control", "no-store").json({
      client_id: entra.clientId,
      client_id_issued_at: Math.floor(Date.now() / 1000),
      client_name: req.body?.client_name || "Claude",
      redirect_uris: uris,
      grant_types: ["authorization_code", "refresh_token"],
      response_types: ["code"],
      token_endpoint_auth_method: "none",
    });
  });

  // Authorization request: validate, then hand off to Entra.
  r.get("/authorize", (req, res) => {
    const q = req.query;
    const redirectUri = String(q.redirect_uri || "");
    if (!allowedRedirectUris.includes(redirectUri)) {
      return res.status(400).type("text/plain").send("This sign-in link isn't from a recognized Claude connector (redirect_uri not allowed).");
    }
    const back = (error, description) => {
      const u = new URL(redirectUri);
      u.searchParams.set("error", error);
      u.searchParams.set("error_description", description);
      if (q.state) u.searchParams.set("state", String(q.state));
      return res.redirect(302, u.toString());
    };
    if (q.client_id !== entra.clientId) return back("unauthorized_client", "Unknown client. Remove and re-add the connector.");
    if (q.response_type !== "code") return back("unsupported_response_type", "Only the authorization code flow is supported.");
    if (!q.code_challenge || q.code_challenge_method !== "S256") return back("invalid_request", "PKCE with S256 is required.");

    const u = new URL(entra.authorizeUrl);
    u.searchParams.set("client_id", entra.clientId);
    u.searchParams.set("response_type", "code");
    u.searchParams.set("redirect_uri", redirectUri);
    u.searchParams.set("response_mode", "query");
    u.searchParams.set("scope", requestScopes);
    u.searchParams.set("code_challenge", String(q.code_challenge));
    u.searchParams.set("code_challenge_method", "S256");
    if (q.state) u.searchParams.set("state", String(q.state));
    // `resource` is intentionally dropped: Entra v2 rejects it.
    res.redirect(302, u.toString());
  });

  // Token request: forward to Entra with the client secret added here.
  r.post("/token", express.json(), async (req, res) => {
    const b = req.body || {};
    const clientId = clientFromRequest(req);
    if (clientId && clientId !== entra.clientId) {
      // Tells Claude to register again (per Claude's connector guidance).
      return oauthError(res, 401, "invalid_client", "Unknown client.");
    }

    const form = new URLSearchParams();
    form.set("client_id", entra.clientId);
    form.set("client_secret", entra.clientSecret);

    if (b.grant_type === "authorization_code") {
      if (!b.code || !b.redirect_uri || !b.code_verifier) return oauthError(res, 400, "invalid_request", "code, redirect_uri and code_verifier are required.");
      if (!allowedRedirectUris.includes(b.redirect_uri)) return oauthError(res, 400, "invalid_grant", "redirect_uri not allowed.");
      form.set("grant_type", "authorization_code");
      form.set("code", b.code);
      form.set("redirect_uri", b.redirect_uri);
      form.set("code_verifier", b.code_verifier);
      form.set("scope", requestScopes);
    } else if (b.grant_type === "refresh_token") {
      if (!b.refresh_token) return oauthError(res, 400, "invalid_request", "refresh_token is required.");
      form.set("grant_type", "refresh_token");
      form.set("refresh_token", b.refresh_token);
      form.set("scope", requestScopes);
    } else {
      return oauthError(res, 400, "unsupported_grant_type", "Use authorization_code or refresh_token.");
    }

    try {
      const upstream = await fetch(entra.tokenUrl, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
        body: form,
      });
      const text = await upstream.text();
      let json;
      try {
        json = JSON.parse(text);
      } catch {
        return oauthError(res, 502, "server_error", "Unexpected response from Microsoft sign-in.");
      }
      if (!upstream.ok) {
        console.warn(`token: Entra refused (${upstream.status}): ${json.error} ${String(json.error_description || "").split("\n")[0]}`);
        // Never forward an Entra invalid_client: that means OUR secret is wrong,
        // not that Claude should re-register.
        if (json.error === "invalid_client") return oauthError(res, 500, "server_error", "The connector's Entra client secret is invalid or expired.");
        return res.status(upstream.status).set("Cache-Control", "no-store").json({ error: json.error, error_description: json.error_description });
      }
      // Return only standard token fields (drop id_token etc.).
      const out = { access_token: json.access_token, token_type: "Bearer", expires_in: json.expires_in, scope: json.scope };
      if (json.refresh_token) out.refresh_token = json.refresh_token;
      res.set("Cache-Control", "no-store").json(out);
    } catch (e) {
      console.error("token: could not reach Entra:", e?.message || e);
      oauthError(res, 502, "server_error", "Could not reach Microsoft sign-in.");
    }
  });

  return r;
}

// ---------- bearer token check for /mcp ----------

const jwks = createRemoteJWKSet(new URL(entra.jwksUrl));

function challenge(res, error, description) {
  let h = `Bearer realm="notes-db", resource_metadata="${prmUrl}"`;
  if (error) h += `, error="${error}", error_description="${description}"`;
  res.status(401).set("WWW-Authenticate", h).json({ error: error || "unauthorized", error_description: description || "Sign in required." });
}

export async function requireUser(req, res, next) {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Bearer ")) return challenge(res);
  try {
    const { payload } = await jwtVerify(h.slice(7), jwks, {
      issuer: entra.issuers,
      audience: [entra.clientId, `api://${entra.clientId}`],
      clockTolerance: 60,
    });
    if (payload.tid && payload.tid !== entra.tenant) return challenge(res, "invalid_token", "Token is from another tenant.");
    const scopes = String(payload.scp || "").split(" ");
    if (!scopes.includes(scopeName)) return challenge(res, "insufficient_scope", `Token lacks the ${scopeName} scope.`);
    if (entra.requiredRole && !(payload.roles || []).includes(entra.requiredRole)) {
      return res.status(403).json({ error: "forbidden", error_description: "You aren't assigned to the Notes DB app. Ask your administrator for access." });
    }
    req.user = {
      id: payload.oid || payload.sub,
      displayName: String(payload.name || payload.preferred_username || payload.upn || payload.unique_name || payload.email || payload.oid || "Unknown"),
      email: payload.preferred_username || payload.upn || payload.email || null,
    };
    next();
  } catch (e) {
    challenge(res, "invalid_token", "Sign-in expired or invalid.");
  }
}
