#!/usr/bin/env node
// Notes DB remote MCP server: Streamable HTTP + Entra ID sign-in.
import express from "express";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { config } from "./config.mjs";
import { oauthRouter, requireUser } from "./auth.mjs";
import { buildServer } from "./tools.mjs";
import { describeTarget } from "./db.mjs";

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", "loopback"); // the reverse proxy runs on this machine

app.get("/healthz", (_req, res) => res.type("text/plain").send("ok"));
app.use(oauthRouter());

// Stateless Streamable HTTP: one short-lived MCP server per request, JSON
// responses (no long-lived SSE streams through the reverse proxy).
app.post(config.mcpPath, express.json({ limit: "1mb" }), requireUser, async (req, res) => {
  const server = buildServer(req.user);
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
  res.on("close", () => {
    transport.close();
    server.close();
  });
  try {
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (e) {
    console.error("mcp:", e?.message || e);
    if (!res.headersSent) res.status(500).json({ jsonrpc: "2.0", error: { code: -32603, message: "Internal server error" }, id: null });
  }
});

const notAllowed = (_req, res) =>
  res.status(405).set("Allow", "POST").json({ jsonrpc: "2.0", error: { code: -32000, message: "Method not allowed." }, id: null });
app.get(config.mcpPath, requireUser, notAllowed);
app.delete(config.mcpPath, requireUser, notAllowed);

app.listen(config.port, config.host, () => {
  console.log(`notes-db-remote: listening on http://${config.host}:${config.port}${config.mcpPath}`);
  console.log(`notes-db-remote: public URL ${config.baseUrl}${config.mcpPath}`);
  console.log(`notes-db-remote: database ${describeTarget()}`);
});
